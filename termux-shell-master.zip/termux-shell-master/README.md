# TERMUX Parrot Shell 
#### Beautify your Termux App 😎

## [+] Installation & Usage
```
apt update
apt install git -y
git clone https://github.com/htr-tech/termux-shell.git
cd termux-shell
chmod +x *
sh install.sh
exit
```
### or use Single Command
```
apt update && apt install git -y && git clone https://github.com/htr-tech/termux-shell.git && cd termux-shell && chmod +x * && sh install.sh
```

#### Credit : https://github.com/TechnicalMujeeb/

    
## [+] Find Me on :
#### Instagram : @tahmid.rayat
#### Facebook : tahmid.rayat.official
#### Github : htr-tech
